// Add a click event listener to the image
document.getElementById("leftImage").addEventListener("click", function () {
    window.location.href = "falling.html"; // Redirect to the next page
});